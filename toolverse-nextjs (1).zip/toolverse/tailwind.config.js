/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        tv: {
          bg: '#0A0E1A',
          surface: '#111827',
          card: '#161D2E',
          border: '#1E2A3D',
          accent: '#6366F1',
          accent2: '#8B5CF6',
          cyan: '#06B6D4',
          green: '#10B981',
          text: '#F1F5F9',
          muted: '#94A3B8',
          dim: '#475569',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
}
