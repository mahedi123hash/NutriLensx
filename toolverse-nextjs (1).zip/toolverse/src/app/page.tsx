import { TOOLS, CATEGORIES, BLOG_POSTS } from '@/lib/tools'
import HeroSearch from '@/components/ui/HeroSearch'
import ToolCard from '@/components/tools/ToolCard'
import BlogCard from '@/components/ui/BlogCard'
import CategoryCard from '@/components/ui/CategoryCard'
import StatsBanner from '@/components/ui/StatsBanner'
import AdBanner from '@/components/ui/AdBanner'

export default function HomePage() {
  const popularTools = TOOLS.filter(t => t.badge === 'popular' || t.badge === 'hot').slice(0, 12)

  return (
    <>
      <StatsBanner />

      {/* HERO */}
      <section style={{
        padding: '52px 24px 40px',
        textAlign: 'center',
        background: 'radial-gradient(ellipse 80% 50% at 50% 0%, rgba(99,102,241,0.12), transparent)',
      }}>
        <h1 style={{
          fontSize: 'clamp(28px, 5vw, 46px)',
          fontWeight: 800,
          lineHeight: 1.2,
          marginBottom: 14,
          background: 'linear-gradient(135deg, #F1F5F9 40%, #94A3B8)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
        }}>
          All The Tools<br />You&apos;ll Ever Need
        </h1>
        <p style={{ color: '#94A3B8', fontSize: 16, maxWidth: 480, margin: '0 auto 28px' }}>
          50+ free online tools for calculators, PDF, image, SEO, text and developer utilities — no sign-up needed.
        </p>
        <HeroSearch />
      </section>

      {/* AD */}
      <div style={{ padding: '0 24px 8px' }}>
        <AdBanner size="728x90" label="Advertisement" />
      </div>

      {/* CATEGORIES */}
      <section style={{ padding: '28px 24px' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, marginBottom: 16, color: '#F1F5F9' }}>
          Browse by <span style={{ color: '#6366F1' }}>Category</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10 }}>
          {CATEGORIES.map(cat => (
            <CategoryCard key={cat.slug} category={cat} count={TOOLS.filter(t => t.category === cat.slug).length} />
          ))}
        </div>
      </section>

      {/* POPULAR TOOLS */}
      <section style={{ padding: '8px 24px 28px' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, marginBottom: 16, color: '#F1F5F9' }}>
          Popular <span style={{ color: '#6366F1' }}>Tools</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 10 }}>
          {popularTools.map(tool => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </section>

      {/* ALL TOOLS */}
      <section style={{ padding: '8px 24px 28px' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, marginBottom: 16, color: '#F1F5F9' }}>
          All <span style={{ color: '#6366F1' }}>50+ Tools</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))', gap: 10 }}>
          {TOOLS.map(tool => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>
      </section>

      {/* AD */}
      <div style={{ padding: '0 24px' }}>
        <AdBanner size="728x90" label="Advertisement" />
      </div>

      {/* BLOG */}
      <section style={{ padding: '28px 24px 40px' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, marginBottom: 16, color: '#F1F5F9' }}>
          Latest <span style={{ color: '#6366F1' }}>Blog Posts</span>
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
          {BLOG_POSTS.map(post => (
            <BlogCard key={post.slug} post={post} />
          ))}
        </div>
      </section>
    </>
  )
}
