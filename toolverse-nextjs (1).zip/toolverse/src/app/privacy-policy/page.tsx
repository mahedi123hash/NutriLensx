import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Privacy Policy - ToolVerse',
  description: 'Read the ToolVerse privacy policy to understand how we handle your data.',
}

export default function PrivacyPolicyPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '48px 24px' }}>
      <h1 style={{ fontSize: 32, fontWeight: 700, color: '#F1F5F9', marginBottom: 8 }}>Privacy Policy</h1>
      <p style={{ color: '#475569', fontSize: 13, marginBottom: 32 }}>Last updated: December 2024</p>
      <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 32, lineHeight: 1.9, color: '#94A3B8', fontSize: 14 }}>
        {[
          ['Information We Collect', 'We do not collect personal information unless you voluntarily contact us. Most tools on ToolVerse operate entirely within your browser and do not transmit data to our servers.'],
          ['Cookies & Analytics', 'We may use cookies and analytics tools (such as Google Analytics) to understand how visitors use our site. This data is anonymized and used only to improve our services.'],
          ['Advertising', 'We use Google AdSense to display advertisements. Google may use cookies to show relevant ads based on your browsing history. You can opt out via Google\'s ad settings.'],
          ['Third-Party Links', 'Our website may contain links to third-party websites. We are not responsible for the privacy practices of those sites.'],
          ['Data Security', 'We implement reasonable security measures. However, no method of transmission over the internet is 100% secure.'],
          ['Children\'s Privacy', 'ToolVerse does not knowingly collect personal information from children under the age of 13.'],
          ['Changes to This Policy', 'We may update this privacy policy from time to time. Changes will be posted on this page with an updated date.'],
          ['Contact Us', 'If you have questions about this privacy policy, please contact us through our Contact page.'],
        ].map(([title, content]) => (
          <div key={title} style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 17, fontWeight: 600, color: '#F1F5F9', marginBottom: 8 }}>{title}</h2>
            <p>{content}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
