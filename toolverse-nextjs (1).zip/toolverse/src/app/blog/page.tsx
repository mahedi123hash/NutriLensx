import { Metadata } from 'next'
import { BLOG_POSTS } from '@/lib/tools'
import BlogCard from '@/components/ui/BlogCard'

export const metadata: Metadata = {
  title: 'Blog - Free Tools Guides & Tutorials',
  description: 'Learn how to use online tools effectively with our guides, tutorials and tips.',
}

export default function BlogPage() {
  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px' }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, color: '#F1F5F9', marginBottom: 8 }}>Blog</h1>
      <p style={{ color: '#94A3B8', marginBottom: 32 }}>Guides, tutorials and tips for using free online tools effectively.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
        {BLOG_POSTS.map(post => <BlogCard key={post.slug} post={post} />)}
      </div>
    </div>
  )
}
