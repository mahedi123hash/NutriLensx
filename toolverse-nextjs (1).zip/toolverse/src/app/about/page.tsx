import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'About Us - ToolVerse',
  description: 'Learn about ToolVerse, your go-to destination for free online tools.',
}

export default function AboutPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '48px 24px' }}>
      <h1 style={{ fontSize: 32, fontWeight: 700, color: '#F1F5F9', marginBottom: 16 }}>About ToolVerse</h1>
      <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 32, lineHeight: 1.8, color: '#94A3B8', fontSize: 15 }}>
        <p style={{ marginBottom: 16 }}>
          <strong style={{ color: '#F1F5F9' }}>ToolVerse</strong> is a free online tools platform built to make everyday digital tasks easier for everyone — students, professionals, developers, and businesses alike.
        </p>
        <p style={{ marginBottom: 16 }}>
          We believe that powerful tools should be free, fast, and accessible to everyone without requiring sign-ups, subscriptions, or downloads.
        </p>
        <h2 style={{ fontSize: 20, fontWeight: 600, color: '#F1F5F9', marginBottom: 12, marginTop: 28 }}>Our Mission</h2>
        <p style={{ marginBottom: 16 }}>
          To provide 100+ high-quality, browser-based tools that work instantly — saving you time and getting out of your way.
        </p>
        <h2 style={{ fontSize: 20, fontWeight: 600, color: '#F1F5F9', marginBottom: 12, marginTop: 28 }}>What We Offer</h2>
        <ul style={{ paddingLeft: 20, marginBottom: 16 }}>
          {['50+ free tools across 8 categories', 'No account required — ever', 'Privacy-first: most tools run entirely in your browser', 'Mobile-friendly design', 'Constantly growing tool library'].map(item => (
            <li key={item} style={{ marginBottom: 8 }}>{item}</li>
          ))}
        </ul>
        <h2 style={{ fontSize: 20, fontWeight: 600, color: '#F1F5F9', marginBottom: 12, marginTop: 28 }}>Privacy</h2>
        <p>
          Most of our tools process data entirely in your browser. We do not store, collect, or transmit your data to any server. Your privacy is our priority.
        </p>
      </div>
    </div>
  )
}
