import type { Metadata } from 'next'
import '../styles/globals.css'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'

export const metadata: Metadata = {
  title: {
    default: 'ToolVerse - 50+ Free Online Tools',
    template: '%s | ToolVerse',
  },
  description: '50+ free online tools for calculators, PDF, image, SEO, text and developer utilities. No sign-up needed.',
  keywords: ['free online tools', 'calculator', 'pdf tools', 'image tools', 'seo tools', 'developer tools'],
  authors: [{ name: 'ToolVerse' }],
  creator: 'ToolVerse',
  metadataBase: new URL('https://toolverse.app'),
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://toolverse.app',
    title: 'ToolVerse - 50+ Free Online Tools',
    description: '50+ free online tools for calculators, PDF, image, SEO, text and developer utilities.',
    siteName: 'ToolVerse',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ToolVerse - 50+ Free Online Tools',
    description: '50+ free online tools — no sign-up needed.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
