import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { TOOLS, getToolBySlug, getRelatedTools } from '@/lib/tools'
import ToolRenderer from '@/components/tools/ToolRenderer'
import AdBanner from '@/components/ui/AdBanner'
import Link from 'next/link'

interface Props {
  params: { slug: string }
}

export async function generateStaticParams() {
  return TOOLS.map(tool => ({ slug: tool.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const tool = getToolBySlug(params.slug)
  if (!tool) return {}
  return {
    title: `${tool.name} - Free Online Tool`,
    description: tool.longDescription,
    keywords: tool.keywords,
    openGraph: {
      title: `${tool.name} | ToolVerse`,
      description: tool.longDescription,
    },
  }
}

export default function ToolPage({ params }: Props) {
  const tool = getToolBySlug(params.slug)
  if (!tool) notFound()

  const related = getRelatedTools(tool)

  return (
    <div style={{ padding: '20px 24px', maxWidth: 1200, margin: '0 auto' }}>
      {/* BREADCRUMB */}
      <nav style={{ fontSize: 12, color: '#475569', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 6 }}>
        <Link href="/" style={{ color: '#475569', textDecoration: 'none' }}>Home</Link>
        <span>›</span>
        <Link href={`/?category=${tool.category}`} style={{ color: '#475569', textDecoration: 'none', textTransform: 'capitalize' }}>{tool.category}</Link>
        <span>›</span>
        <span style={{ color: '#F1F5F9' }}>{tool.name}</span>
      </nav>

      <Link href="/" style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '7px 14px', background: '#111827', border: '1px solid #1E2A3D',
        borderRadius: 8, fontSize: 13, color: '#94A3B8', textDecoration: 'none', marginBottom: 20,
      }}>
        ← Back to Tools
      </Link>

      {/* TOOL HEADER */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 6, color: '#F1F5F9' }}>
          {tool.icon} {tool.name}
        </h1>
        <p style={{ color: '#94A3B8', fontSize: 15 }}>{tool.longDescription}</p>
      </div>

      {/* AD ABOVE TOOL */}
      <AdBanner size="728x90" label="Advertisement" style={{ marginBottom: 16 }} />

      {/* TOOL BODY */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        {/* MAIN */}
        <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 24 }}>
          <ToolRenderer tool={tool} />
        </div>

        {/* SIDEBAR */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <AdBanner size="300x250" label="Advertisement" style={{ height: 280 }} />

          {/* RELATED TOOLS */}
          <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, color: '#F1F5F9' }}>Related Tools</div>
            {related.map(r => (
              <Link key={r.id} href={`/tools/${r.slug}`} style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '7px 0',
                borderBottom: '1px solid #1E2A3D', textDecoration: 'none', color: '#94A3B8', fontSize: 13,
              }}>
                <span style={{ fontSize: 16 }}>{r.icon}</span>
                <span style={{ flex: 1 }}>{r.name}</span>
                <span>›</span>
              </Link>
            ))}
          </div>

          <AdBanner size="300x250" label="Advertisement" style={{ height: 280 }} />
        </div>
      </div>

      {/* AD BELOW TOOL */}
      <AdBanner size="728x90" label="Advertisement" style={{ marginTop: 16 }} />

      {/* SEO CONTENT */}
      <section style={{ marginTop: 40, background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 24 }}>
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 12, color: '#F1F5F9' }}>About {tool.name}</h2>
        <p style={{ color: '#94A3B8', fontSize: 14, lineHeight: 1.8 }}>{tool.longDescription}</p>
        <h3 style={{ fontSize: 15, fontWeight: 600, marginTop: 20, marginBottom: 8, color: '#F1F5F9' }}>How to use this tool</h3>
        <ol style={{ color: '#94A3B8', fontSize: 14, paddingLeft: 20, lineHeight: 2 }}>
          <li>Enter your input in the fields provided above</li>
          <li>Click the calculate or generate button</li>
          <li>View your results instantly — no sign-up or download required</li>
          <li>Copy or download your results as needed</li>
        </ol>
      </section>
    </div>
  )
}
