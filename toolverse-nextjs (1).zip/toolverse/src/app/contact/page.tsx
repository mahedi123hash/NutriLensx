import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Contact Us - ToolVerse',
  description: 'Get in touch with the ToolVerse team.',
}

export default function ContactPage() {
  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: '48px 24px' }}>
      <h1 style={{ fontSize: 32, fontWeight: 700, color: '#F1F5F9', marginBottom: 8 }}>Contact Us</h1>
      <p style={{ color: '#94A3B8', marginBottom: 32 }}>Have a question, suggestion, or found a bug? We'd love to hear from you.</p>
      <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 28 }}>
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>Your Name</label>
          <input type="text" placeholder="John Doe" style={{ width: '100%', background: '#111827', border: '1px solid #1E2A3D', borderRadius: 8, padding: '10px 12px', color: '#F1F5F9', fontSize: 14, outline: 'none', fontFamily: 'inherit' }} />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>Email Address</label>
          <input type="email" placeholder="john@example.com" style={{ width: '100%', background: '#111827', border: '1px solid #1E2A3D', borderRadius: 8, padding: '10px 12px', color: '#F1F5F9', fontSize: 14, outline: 'none', fontFamily: 'inherit' }} />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>Subject</label>
          <input type="text" placeholder="Tool suggestion, bug report, etc." style={{ width: '100%', background: '#111827', border: '1px solid #1E2A3D', borderRadius: 8, padding: '10px 12px', color: '#F1F5F9', fontSize: 14, outline: 'none', fontFamily: 'inherit' }} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 6 }}>Message</label>
          <textarea rows={5} placeholder="Tell us more..." style={{ width: '100%', background: '#111827', border: '1px solid #1E2A3D', borderRadius: 8, padding: '10px 12px', color: '#F1F5F9', fontSize: 14, outline: 'none', resize: 'vertical', fontFamily: 'inherit' }} />
        </div>
        <button style={{ width: '100%', background: '#6366F1', color: '#fff', border: 'none', borderRadius: 8, padding: '12px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
          Send Message
        </button>
        <p style={{ fontSize: 12, color: '#475569', marginTop: 12, textAlign: 'center' }}>We typically respond within 24–48 hours.</p>
      </div>
    </div>
  )
}
