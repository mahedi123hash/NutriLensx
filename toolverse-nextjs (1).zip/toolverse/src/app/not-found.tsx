import Link from 'next/link'

export default function NotFound() {
  return (
    <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 24 }}>
      <div>
        <div style={{ fontSize: 64, marginBottom: 16 }}>🔧</div>
        <h1 style={{ fontSize: 32, fontWeight: 700, color: '#F1F5F9', marginBottom: 8 }}>Page Not Found</h1>
        <p style={{ color: '#94A3B8', marginBottom: 28, fontSize: 15 }}>The page you're looking for doesn't exist or has been moved.</p>
        <Link href="/" style={{
          background: '#6366F1', color: '#fff', textDecoration: 'none',
          padding: '10px 24px', borderRadius: 8, fontWeight: 600, fontSize: 14,
        }}>
          ← Back to All Tools
        </Link>
      </div>
    </div>
  )
}
