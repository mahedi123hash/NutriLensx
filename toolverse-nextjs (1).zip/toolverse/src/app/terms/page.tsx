import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Terms & Conditions - ToolVerse',
  description: 'Read the ToolVerse terms and conditions of use.',
}

export default function TermsPage() {
  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '48px 24px' }}>
      <h1 style={{ fontSize: 32, fontWeight: 700, color: '#F1F5F9', marginBottom: 8 }}>Terms & Conditions</h1>
      <p style={{ color: '#475569', fontSize: 13, marginBottom: 32 }}>Last updated: December 2024</p>
      <div style={{ background: '#161D2E', border: '1px solid #1E2A3D', borderRadius: 12, padding: 32, lineHeight: 1.9, color: '#94A3B8', fontSize: 14 }}>
        {[
          ['Acceptance of Terms', 'By accessing and using ToolVerse, you accept and agree to be bound by these Terms and Conditions. If you do not agree, please do not use our website.'],
          ['Use of Tools', 'All tools provided on ToolVerse are for lawful purposes only. You agree not to use the tools to process any illegal, harmful, or offensive content.'],
          ['Intellectual Property', 'All content, design, and code on ToolVerse is owned by ToolVerse and protected by applicable intellectual property laws.'],
          ['Disclaimer of Warranties', 'Tools are provided "as is" without warranties of any kind. We do not guarantee accuracy, completeness, or fitness for a particular purpose.'],
          ['Limitation of Liability', 'ToolVerse shall not be liable for any direct, indirect, incidental, or consequential damages arising from your use of the website or its tools.'],
          ['Advertising', 'ToolVerse displays third-party advertisements. We are not responsible for the content of those ads or the practices of advertisers.'],
          ['Changes to Terms', 'We reserve the right to modify these terms at any time. Continued use of the website after changes constitutes acceptance of the new terms.'],
          ['Governing Law', 'These terms are governed by applicable laws. Any disputes shall be resolved in the appropriate jurisdiction.'],
        ].map(([title, content]) => (
          <div key={title} style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 17, fontWeight: 600, color: '#F1F5F9', marginBottom: 8 }}>{title}</h2>
            <p>{content}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
