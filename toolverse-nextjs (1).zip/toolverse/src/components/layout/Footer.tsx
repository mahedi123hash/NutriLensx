import Link from 'next/link'

export default function Footer() {
  return (
    <footer style={{ background: '#111827', borderTop: '1px solid #1E2A3D', padding: '32px 24px 20px', marginTop: 40 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 24, marginBottom: 28, maxWidth: 1200, margin: '0 auto 28px' }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 700, background: 'linear-gradient(135deg,#6366F1,#8B5CF6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 8 }}>
            🛠 ToolVerse
          </div>
          <p style={{ fontSize: 13, color: '#475569', lineHeight: 1.6, maxWidth: 220 }}>
            50+ free online tools for everyday tasks. No sign-up, no download, no cost.
          </p>
        </div>
        <div>
          <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, color: '#F1F5F9' }}>Tools</h4>
          {['Calculators', 'Text Tools', 'PDF Tools', 'Image Tools', 'SEO Tools', 'Developer Tools'].map(t => (
            <Link key={t} href={`/?category=${t.toLowerCase().split(' ')[0]}`} style={{ display: 'block', fontSize: 12, color: '#475569', marginBottom: 6, textDecoration: 'none' }}>{t}</Link>
          ))}
        </div>
        <div>
          <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, color: '#F1F5F9' }}>Company</h4>
          {[['About Us', '/about'], ['Contact Us', '/contact'], ['Blog', '/blog'], ['Sitemap', '/sitemap.xml']].map(([label, href]) => (
            <Link key={href} href={href} style={{ display: 'block', fontSize: 12, color: '#475569', marginBottom: 6, textDecoration: 'none' }}>{label}</Link>
          ))}
        </div>
        <div>
          <h4 style={{ fontSize: 13, fontWeight: 600, marginBottom: 10, color: '#F1F5F9' }}>Legal</h4>
          {[['Privacy Policy', '/privacy-policy'], ['Terms & Conditions', '/terms'], ['Disclaimer', '/disclaimer'], ['Cookie Policy', '/cookies']].map(([label, href]) => (
            <Link key={href} href={href} style={{ display: 'block', fontSize: 12, color: '#475569', marginBottom: 6, textDecoration: 'none' }}>{label}</Link>
          ))}
        </div>
      </div>
      <div style={{ borderTop: '1px solid #1E2A3D', paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: 1200, margin: '0 auto' }}>
        <p style={{ fontSize: 11, color: '#475569' }}>© {new Date().getFullYear()} ToolVerse. All rights reserved.</p>
        <div style={{ display: 'flex', gap: 12 }}>
          {[['Privacy', '/privacy-policy'], ['Terms', '/terms'], ['Disclaimer', '/disclaimer'], ['Contact', '/contact']].map(([label, href]) => (
            <Link key={href} href={href} style={{ fontSize: 11, color: '#475569', textDecoration: 'none' }}>{label}</Link>
          ))}
        </div>
      </div>
    </footer>
  )
}
