'use client'
import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Navbar() {
  const [query, setQuery] = useState('')
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) router.push(`/?q=${encodeURIComponent(query)}`)
  }

  return (
    <nav style={{
      background: 'rgba(10,14,26,0.95)',
      borderBottom: '1px solid #1E2A3D',
      padding: '0 24px',
      height: 56,
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      position: 'sticky',
      top: 0,
      zIndex: 100,
      backdropFilter: 'blur(8px)',
    }}>
      <Link href="/" style={{
        fontSize: 18, fontWeight: 700, textDecoration: 'none',
        background: 'linear-gradient(135deg,#6366F1,#8B5CF6)',
        WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
        whiteSpace: 'nowrap',
      }}>
        🛠 ToolVerse
      </Link>

      <form onSubmit={handleSearch} style={{ flex: 1, maxWidth: 420, position: 'relative' }}>
        <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#475569', fontSize: 15 }}>🔍</span>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search 50+ tools..."
          style={{
            width: '100%',
            background: '#111827',
            border: '1px solid #1E2A3D',
            borderRadius: 8,
            padding: '7px 12px 7px 34px',
            color: '#F1F5F9',
            fontSize: 13,
            outline: 'none',
          }}
        />
      </form>

      <div style={{ display: 'flex', gap: 4, marginLeft: 'auto' }}>
        {[
          { label: 'Home', href: '/' },
          { label: 'Blog', href: '/blog' },
          { label: 'About', href: '/about' },
          { label: 'Contact', href: '/contact' },
        ].map(link => (
          <Link key={link.href} href={link.href} style={{
            padding: '5px 10px', borderRadius: 6, fontSize: 13, color: '#94A3B8', textDecoration: 'none',
          }}>
            {link.label}
          </Link>
        ))}
      </div>
    </nav>
  )
}
