export default function StatsBanner() {
  const stats = [
    { num: '50+', label: 'Free Tools' },
    { num: '8', label: 'Categories' },
    { num: '0', label: 'Sign-up Required' },
    { num: '100%', label: 'Free Forever' },
    { num: '24/7', label: 'Available' },
  ]
  return (
    <div style={{
      background: '#111827',
      borderBottom: '1px solid #1E2A3D',
      padding: '8px 24px',
      display: 'flex',
      gap: 24,
      overflowX: 'auto',
    }}>
      {stats.map(s => (
        <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: '#6366F1' }}>{s.num}</span>
          <span style={{ fontSize: 11, color: '#475569' }}>{s.label}</span>
        </div>
      ))}
    </div>
  )
}
