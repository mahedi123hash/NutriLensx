import Link from 'next/link'

interface CategoryCardProps {
  category: { slug: string; name: string; icon: string; color: string }
  count: number
}

export default function CategoryCard({ category, count }: CategoryCardProps) {
  return (
    <Link href={`/?category=${category.slug}`} style={{ textDecoration: 'none' }}>
      <div style={{
        background: '#161D2E',
        border: '1px solid #1E2A3D',
        borderRadius: 12,
        padding: '16px 14px',
        cursor: 'pointer',
        textAlign: 'center',
        transition: 'all 0.2s',
      }}
        onMouseEnter={e => {
          const el = e.currentTarget as HTMLDivElement
          el.style.borderColor = category.color
          el.style.background = category.color + '10'
          el.style.transform = 'translateY(-2px)'
        }}
        onMouseLeave={e => {
          const el = e.currentTarget as HTMLDivElement
          el.style.borderColor = '#1E2A3D'
          el.style.background = '#161D2E'
          el.style.transform = 'translateY(0)'
        }}
      >
        <div style={{ fontSize: 24, marginBottom: 8 }}>{category.icon}</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#F1F5F9' }}>{category.name}</div>
        <div style={{ fontSize: 11, color: '#475569', marginTop: 2 }}>{count} tools</div>
      </div>
    </Link>
  )
}
