import Link from 'next/link'

interface BlogPost {
  slug: string
  title: string
  category: string
  emoji: string
  date: string
  readTime: string
  excerpt: string
}

export default function BlogCard({ post }: { post: BlogPost }) {
  return (
    <Link href={`/blog/${post.slug}`} style={{ textDecoration: 'none' }}>
      <div style={{
        background: '#161D2E',
        border: '1px solid #1E2A3D',
        borderRadius: 12,
        overflow: 'hidden',
        cursor: 'pointer',
        transition: 'all 0.2s',
        height: '100%',
      }}
        onMouseEnter={e => {
          const el = e.currentTarget as HTMLDivElement
          el.style.borderColor = '#6366F1'
          el.style.transform = 'translateY(-2px)'
        }}
        onMouseLeave={e => {
          const el = e.currentTarget as HTMLDivElement
          el.style.borderColor = '#1E2A3D'
          el.style.transform = 'translateY(0)'
        }}
      >
        <div style={{ height: 100, background: '#111827', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40 }}>
          {post.emoji}
        </div>
        <div style={{ padding: 14 }}>
          <div style={{ fontSize: 10, color: '#6366F1', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 5 }}>
            {post.category}
          </div>
          <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.4, color: '#F1F5F9', marginBottom: 6 }}>
            {post.title}
          </div>
          <div style={{ fontSize: 12, color: '#475569', lineHeight: 1.5, marginBottom: 6 }}>
            {post.excerpt}
          </div>
          <div style={{ fontSize: 11, color: '#475569' }}>
            {post.date} · {post.readTime} read
          </div>
        </div>
      </div>
    </Link>
  )
}
