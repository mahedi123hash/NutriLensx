'use client'
import { CSSProperties } from 'react'

// AD BANNER
export function AdBanner({ size, label, style }: { size: string; label: string; style?: CSSProperties }) {
  const [w, h] = size.split('x').map(Number)
  return (
    <div style={{
      background: '#161D2E',
      border: '1px solid #1E2A3D',
      borderRadius: 8,
      padding: '6px 12px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      ...style,
    }}>
      <span style={{ fontSize: 10, color: '#475569', textTransform: 'uppercase', letterSpacing: 1 }}>{label}</span>
      <div style={{
        background: '#111827',
        borderRadius: 4,
        padding: '4px 16px',
        fontSize: 11,
        color: '#475569',
        minHeight: h > 90 ? h : undefined,
        display: 'flex',
        alignItems: 'center',
        flex: h > 90 ? 1 : undefined,
        justifyContent: 'center',
        marginLeft: h > 90 ? 0 : 8,
      }}>
        {/* Replace with real AdSense code */}
        {/* <ins className="adsbygoogle" style={{display:'block'}} data-ad-client="ca-pub-XXXXXXXX" data-ad-slot="XXXXXXXX" data-ad-format="auto" /> */}
        Ad · {size}
      </div>
    </div>
  )
}

export default AdBanner
