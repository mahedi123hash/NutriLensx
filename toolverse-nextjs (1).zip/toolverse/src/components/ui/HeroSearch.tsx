'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

const POPULAR_TAGS = ['Age Calculator', 'BMI Calculator', 'JSON Formatter', 'QR Generator', 'PDF Tools', 'Password Generator', 'Base64']

export default function HeroSearch() {
  const [query, setQuery] = useState('')
  const router = useRouter()

  const search = (q: string) => {
    if (q.trim()) router.push(`/?q=${encodeURIComponent(q)}`)
  }

  return (
    <div>
      <div style={{ maxWidth: 560, margin: '0 auto', position: 'relative' }}>
        <span style={{ position: 'absolute', left: 15, top: '50%', transform: 'translateY(-50%)', color: '#475569', fontSize: 18 }}>🔍</span>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && search(query)}
          placeholder="Try: age calculator, JSON formatter, QR generator..."
          style={{
            width: '100%',
            background: '#111827',
            border: '1.5px solid #1E2A3D',
            borderRadius: 12,
            padding: '14px 80px 14px 46px',
            color: '#F1F5F9',
            fontSize: 15,
            outline: 'none',
            fontFamily: 'inherit',
          }}
        />
        <button
          onClick={() => search(query)}
          style={{
            position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)',
            background: '#6366F1', color: '#fff', border: 'none', borderRadius: 8,
            padding: '6px 14px', fontSize: 13, cursor: 'pointer', fontWeight: 600,
          }}
        >
          Search
        </button>
      </div>
      <div style={{ marginTop: 16, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 8 }}>
        {POPULAR_TAGS.map(tag => (
          <button
            key={tag}
            onClick={() => search(tag)}
            style={{
              padding: '4px 12px',
              background: '#111827',
              border: '1px solid #1E2A3D',
              borderRadius: 20,
              fontSize: 12,
              color: '#94A3B8',
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            {tag}
          </button>
        ))}
      </div>
    </div>
  )
}
