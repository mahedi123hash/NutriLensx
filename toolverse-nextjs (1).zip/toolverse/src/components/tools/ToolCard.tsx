import Link from 'next/link'
import { Tool } from '@/lib/tools'

const BADGE_STYLES: Record<string, { bg: string; color: string; label: string }> = {
  popular: { bg: 'rgba(99,102,241,0.15)', color: '#818CF8', label: '⭐ Popular' },
  new: { bg: 'rgba(16,185,129,0.15)', color: '#34D399', label: '✨ New' },
  hot: { bg: 'rgba(239,68,68,0.15)', color: '#F87171', label: '🔥 Hot' },
}

export default function ToolCard({ tool }: { tool: Tool }) {
  const badge = tool.badge ? BADGE_STYLES[tool.badge] : null

  return (
    <Link href={`/tools/${tool.slug}`} style={{ textDecoration: 'none' }}>
      <div style={{
        background: '#161D2E',
        border: '1px solid #1E2A3D',
        borderRadius: 12,
        padding: 14,
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
        height: '100%',
        transition: 'border-color 0.2s, transform 0.2s',
      }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLDivElement).style.borderColor = '#6366F1'
          ;(e.currentTarget as HTMLDivElement).style.transform = 'translateY(-1px)'
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLDivElement).style.borderColor = '#1E2A3D'
          ;(e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 8,
            background: tool.color + '22',
            color: tool.color,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, fontFamily: 'monospace', flexShrink: 0,
          }}>
            {tool.icon}
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#F1F5F9' }}>{tool.name}</div>
        </div>
        <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.4 }}>{tool.description}</div>
        {badge && (
          <span style={{
            fontSize: 10, padding: '2px 7px', borderRadius: 10, fontWeight: 600,
            alignSelf: 'flex-start', background: badge.bg, color: badge.color,
          }}>
            {badge.label}
          </span>
        )}
      </div>
    </Link>
  )
}
