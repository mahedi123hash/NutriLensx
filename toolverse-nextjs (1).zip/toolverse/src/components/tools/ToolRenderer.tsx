'use client'
import { Tool } from '@/lib/tools'
import AgeCalculator from './implementations/AgeCalculator'
import BMICalculator from './implementations/BMICalculator'
import PercentageCalculator from './implementations/PercentageCalculator'
import WordCounter from './implementations/WordCounter'
import JsonFormatter from './implementations/JsonFormatter'
import PasswordGenerator from './implementations/PasswordGenerator'
import Base64Tool from './implementations/Base64Tool'
import ColorPicker from './implementations/ColorPicker'
import LoremIpsum from './implementations/LoremIpsum'
import UUIDGenerator from './implementations/UUIDGenerator'
import TextCaseConverter from './implementations/TextCaseConverter'
import BinaryConverter from './implementations/BinaryConverter'
import MetaTagGenerator from './implementations/MetaTagGenerator'
import RandomNumber from './implementations/RandomNumber'
import DefaultTool from './implementations/DefaultTool'

const TOOL_MAP: Record<string, React.ComponentType<{ tool: Tool }>> = {
  'age-calculator': AgeCalculator,
  'bmi-calculator': BMICalculator,
  'percentage-calculator': PercentageCalculator,
  'word-counter': WordCounter,
  'character-counter': WordCounter,
  'json-formatter': JsonFormatter,
  'json-validator': JsonFormatter,
  'password-generator': PasswordGenerator,
  'base64-encoder': Base64Tool,
  'base64-decoder': Base64Tool,
  'color-picker': ColorPicker,
  'lorem-ipsum': LoremIpsum,
  'uuid-generator': UUIDGenerator,
  'text-case': TextCaseConverter,
  'binary-converter': BinaryConverter,
  'meta-tag-generator': MetaTagGenerator,
  'random-number': RandomNumber,
}

export default function ToolRenderer({ tool }: { tool: Tool }) {
  const Component = TOOL_MAP[tool.slug] || DefaultTool
  return <Component tool={tool} />
}
