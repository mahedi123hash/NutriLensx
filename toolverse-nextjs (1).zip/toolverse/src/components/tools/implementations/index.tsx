'use client'
import { useState, useEffect } from 'react'
import { Tool } from '@/lib/tools'
import { inputStyle, btnPrimary, btnSecondary, resultBox, monoStyle } from './styles'

// BMI CALCULATOR
export function BMICalculator({ tool: _ }: { tool: Tool }) {
  const [w, setW] = useState('70')
  const [h, setH] = useState('175')
  const [result, setResult] = useState<{ bmi: number; cat: string; color: string } | null>(null)

  const calc = () => {
    const bmi = parseFloat(w) / Math.pow(parseFloat(h) / 100, 2)
    const cat = bmi < 18.5 ? ['Underweight', '#06B6D4'] : bmi < 25 ? ['Normal weight', '#10B981'] : bmi < 30 ? ['Overweight', '#F59E0B'] : ['Obese', '#EF4444']
    setResult({ bmi: Math.round(bmi * 10) / 10, cat: cat[0], color: cat[1] })
  }

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Weight (kg)</label><input type="number" value={w} onChange={e => setW(e.target.value)} style={inputStyle} /></div>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Height (cm)</label><input type="number" value={h} onChange={e => setH(e.target.value)} style={inputStyle} /></div>
      </div>
      <button onClick={calc} style={btnPrimary}>Calculate BMI</button>
      {result && (
        <div style={resultBox}>
          <div style={{ fontSize: 32, fontWeight: 700, color: result.color }}>{result.bmi}</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: result.color }}>{result.cat}</div>
          <div style={{ fontSize: 13, color: '#94A3B8', marginTop: 6 }}>Healthy range: 18.5 – 24.9</div>
        </div>
      )}
    </div>
  )
}

// PERCENTAGE CALCULATOR
export function PercentageCalculator({ tool: _ }: { tool: Tool }) {
  const [x, setX] = useState('15')
  const [y, setY] = useState('200')
  const [result, setResult] = useState<number | null>(null)

  return (
    <div>
      <p style={{ fontSize: 13, color: '#94A3B8', marginBottom: 12 }}>What is X% of Y?</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Percentage (%)</label><input type="number" value={x} onChange={e => setX(e.target.value)} style={inputStyle} /></div>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Number</label><input type="number" value={y} onChange={e => setY(e.target.value)} style={inputStyle} /></div>
      </div>
      <button onClick={() => setResult(Math.round((parseFloat(x) / 100) * parseFloat(y) * 100) / 100)} style={btnPrimary}>Calculate</button>
      {result !== null && (
        <div style={resultBox}>
          <div style={{ fontSize: 32, fontWeight: 700, color: '#6366F1' }}>{result}</div>
          <div style={{ fontSize: 13, color: '#94A3B8', marginTop: 4 }}>{x}% of {y} = {result}</div>
        </div>
      )}
    </div>
  )
}

// WORD COUNTER
export function WordCounter({ tool: _ }: { tool: Tool }) {
  const [text, setText] = useState('')
  const stats = {
    words: text.trim() ? text.trim().split(/\s+/).length : 0,
    chars: text.length,
    sentences: text.trim() ? text.split(/[.!?]+/).filter(s => s.trim()).length : 0,
    paras: text.trim() ? text.split(/\n\s*\n/).filter(p => p.trim()).length : 0,
  }
  return (
    <div>
      <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Enter or paste your text</label>
      <textarea value={text} onChange={e => setText(e.target.value)} rows={8} placeholder="Start typing or paste text here..." style={{ ...inputStyle, resize: 'vertical' }} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginTop: 12 }}>
        {[['Words', stats.words, '#6366F1'], ['Characters', stats.chars, '#8B5CF6'], ['Sentences', stats.sentences, '#06B6D4'], ['Paragraphs', stats.paras, '#10B981']].map(([label, val, color]) => (
          <div key={label as string} style={{ background: '#111827', borderRadius: 8, padding: 10, textAlign: 'center' }}>
            <div style={{ fontSize: 22, fontWeight: 700, color: color as string }}>{val}</div>
            <div style={{ fontSize: 11, color: '#475569' }}>{label}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 10 }}>
        <button onClick={() => setText('')} style={btnSecondary}>Clear</button>
      </div>
    </div>
  )
}

// JSON FORMATTER
export function JsonFormatter({ tool: _ }: { tool: Tool }) {
  const [input, setInput] = useState('{"name":"ToolVerse","version":"1.0","tools":50}')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')

  const format = () => {
    try { setOutput(JSON.stringify(JSON.parse(input), null, 2)); setError('') }
    catch (e: unknown) { setError((e as Error).message); setOutput('') }
  }
  const minify = () => {
    try { setOutput(JSON.stringify(JSON.parse(input))); setError('') }
    catch (e: unknown) { setError((e as Error).message); setOutput('') }
  }
  const validate = () => {
    try { JSON.parse(input); setOutput('✅ Valid JSON!'); setError('') }
    catch (e: unknown) { setError((e as Error).message); setOutput('') }
  }

  return (
    <div>
      <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Paste JSON</label>
      <textarea value={input} onChange={e => setInput(e.target.value)} rows={7} style={{ ...inputStyle, ...monoStyle, resize: 'vertical' }} />
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <button onClick={format} style={btnPrimary}>Format</button>
        <button onClick={minify} style={btnSecondary}>Minify</button>
        <button onClick={validate} style={btnSecondary}>Validate</button>
      </div>
      {(output || error) && (
        <div style={{ ...resultBox, marginTop: 14 }}>
          {error ? <div style={{ color: '#EF4444', ...monoStyle }}>{error}</div>
            : <pre style={{ color: '#10B981', ...monoStyle, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{output}</pre>}
          {output && !error && (
            <button onClick={() => navigator.clipboard.writeText(output)} style={{ ...btnSecondary, marginTop: 8, fontSize: 12, padding: '4px 10px' }}>Copy</button>
          )}
        </div>
      )}
    </div>
  )
}

// PASSWORD GENERATOR
export function PasswordGenerator({ tool: _ }: { tool: Tool }) {
  const [len, setLen] = useState(16)
  const [opts, setOpts] = useState({ upper: true, lower: true, num: true, sym: true })
  const [pwd, setPwd] = useState('')
  const [copied, setCopied] = useState(false)

  const gen = () => {
    let chars = ''
    if (opts.upper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if (opts.lower) chars += 'abcdefghijklmnopqrstuvwxyz'
    if (opts.num) chars += '0123456789'
    if (opts.sym) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?'
    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz'
    let p = ''
    for (let i = 0; i < len; i++) p += chars[Math.floor(Math.random() * chars.length)]
    setPwd(p)
  }

  useEffect(() => { gen() }, [])

  const copy = () => { navigator.clipboard.writeText(pwd); setCopied(true); setTimeout(() => setCopied(false), 2000) }

  return (
    <div>
      <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Length: {len}</label>
      <input type="range" min={6} max={64} value={len} onChange={e => setLen(+e.target.value)} style={{ width: '100%', marginBottom: 14 }} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
        {([['upper', 'Uppercase (A-Z)'], ['lower', 'Lowercase (a-z)'], ['num', 'Numbers (0-9)'], ['sym', 'Symbols (!@#$)']] as [keyof typeof opts, string][]).map(([key, label]) => (
          <label key={key} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#94A3B8', cursor: 'pointer' }}>
            <input type="checkbox" checked={opts[key]} onChange={e => setOpts({ ...opts, [key]: e.target.checked })} />
            {label}
          </label>
        ))}
      </div>
      {pwd && (
        <div style={{ ...resultBox, fontFamily: 'monospace', fontSize: 16, letterSpacing: 2, wordBreak: 'break-all', color: '#F1F5F9' }}>{pwd}</div>
      )}
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button onClick={gen} style={btnPrimary}>🔄 Regenerate</button>
        <button onClick={copy} style={btnSecondary}>{copied ? '✅ Copied!' : '📋 Copy'}</button>
      </div>
    </div>
  )
}

// BASE64
export function Base64Tool({ tool: _ }: { tool: Tool }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')

  return (
    <div>
      <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Input text</label>
      <textarea value={input} onChange={e => setInput(e.target.value)} rows={4} placeholder="Enter text to encode or decode..." style={{ ...inputStyle, resize: 'vertical' }} />
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <button onClick={() => setOutput(btoa(unescape(encodeURIComponent(input))))} style={btnPrimary}>Encode to Base64</button>
        <button onClick={() => { try { setOutput(decodeURIComponent(escape(atob(input)))) } catch { setOutput('Invalid Base64') } }} style={btnSecondary}>Decode</button>
      </div>
      {output && (
        <div style={{ ...resultBox, ...monoStyle, wordBreak: 'break-all', color: '#10B981' }}>
          {output}
          <button onClick={() => navigator.clipboard.writeText(output)} style={{ ...btnSecondary, marginTop: 8, fontSize: 12, padding: '4px 10px', display: 'block' }}>Copy</button>
        </div>
      )}
    </div>
  )
}

// COLOR PICKER
export function ColorPicker({ tool: _ }: { tool: Tool }) {
  const [color, setColor] = useState('#6366F1')

  const hexToRgb = (hex: string) => ({ r: parseInt(hex.slice(1, 3), 16), g: parseInt(hex.slice(3, 5), 16), b: parseInt(hex.slice(5, 7), 16) })
  const toHsl = (r: number, g: number, b: number) => {
    const rn = r / 255, gn = g / 255, bn = b / 255
    const mx = Math.max(rn, gn, bn), mn = Math.min(rn, gn, bn), d = mx - mn
    let h = 0; const l = (mx + mn) / 2
    const s = d ? d / (1 - Math.abs(2 * l - 1)) : 0
    if (d) h = mx === rn ? ((gn - bn) / d + 6) % 6 : mx === gn ? (bn - rn) / d + 2 : (rn - gn) / d + 4
    return `hsl(${Math.round(h * 60)},${Math.round(s * 100)}%,${Math.round(l * 100)}%)`
  }
  const { r, g, b } = hexToRgb(color)

  return (
    <div>
      <input type="color" value={color} onChange={e => setColor(e.target.value)} style={{ width: '100%', height: 60, borderRadius: 8, cursor: 'pointer', border: 'none' }} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 12 }}>
        {[['HEX', color.toUpperCase()], ['RGB', `rgb(${r},${g},${b})`], ['HSL', toHsl(r, g, b)]].map(([label, val]) => (
          <div key={label} style={{ background: '#111827', borderRadius: 8, padding: 10, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: '#475569', marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 12, fontWeight: 600, fontFamily: 'monospace', color: '#F1F5F9' }}>{val}</div>
            <button onClick={() => navigator.clipboard.writeText(val)} style={{ fontSize: 10, marginTop: 4, background: 'transparent', border: '1px solid #1E2A3D', borderRadius: 4, color: '#94A3B8', cursor: 'pointer', padding: '2px 6px' }}>Copy</button>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 12, borderRadius: 8, height: 50, background: color }} />
    </div>
  )
}

// LOREM IPSUM
export function LoremIpsum({ tool: _ }: { tool: Tool }) {
  const [count, setCount] = useState(3)
  const [output, setOutput] = useState('')
  const WORDS = 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur'.split(' ')

  const gen = () => {
    const paras = Array.from({ length: count }, () => Array.from({ length: 20 }, () => WORDS[Math.floor(Math.random() * WORDS.length)]).join(' ') + '.').join('\n\n')
    setOutput(paras)
  }

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Paragraphs</label>
        <input type="number" value={count} min={1} max={20} onChange={e => setCount(+e.target.value)} style={{ ...inputStyle, maxWidth: 120 }} />
      </div>
      <button onClick={gen} style={btnPrimary}>Generate</button>
      {output && (
        <div>
          <div style={{ ...resultBox, lineHeight: 1.8, color: '#94A3B8', fontSize: 14, maxHeight: 300, overflow: 'auto' }}>{output}</div>
          <button onClick={() => navigator.clipboard.writeText(output)} style={{ ...btnSecondary, marginTop: 8, fontSize: 12, padding: '4px 10px' }}>Copy</button>
        </div>
      )}
    </div>
  )
}

// UUID GENERATOR
export function UUIDGenerator({ tool: _ }: { tool: Tool }) {
  const [count, setCount] = useState(5)
  const [uuids, setUuids] = useState<string[]>([])

  const gen = () => {
    setUuids(Array.from({ length: count }, () =>
      'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0
        return (c === 'x' ? r : r & 0x3 | 0x8).toString(16)
      })
    ))
  }

  useEffect(() => { gen() }, [])

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Number of UUIDs</label>
        <input type="number" value={count} min={1} max={100} onChange={e => setCount(+e.target.value)} style={{ ...inputStyle, maxWidth: 120 }} />
      </div>
      <button onClick={gen} style={btnPrimary}>Generate</button>
      {uuids.length > 0 && (
        <div style={{ ...resultBox, ...monoStyle, lineHeight: 2, color: '#10B981' }}>
          {uuids.map((u, i) => <div key={i}>{u}</div>)}
          <button onClick={() => navigator.clipboard.writeText(uuids.join('\n'))} style={{ ...btnSecondary, marginTop: 8, fontSize: 12, padding: '4px 10px' }}>Copy All</button>
        </div>
      )}
    </div>
  )
}

// TEXT CASE CONVERTER
export function TextCaseConverter({ tool: _ }: { tool: Tool }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')

  const convert = (type: string) => {
    if (type === 'upper') setOutput(input.toUpperCase())
    else if (type === 'lower') setOutput(input.toLowerCase())
    else if (type === 'title') setOutput(input.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()))
    else if (type === 'sentence') setOutput(input.charAt(0).toUpperCase() + input.slice(1).toLowerCase())
    else if (type === 'camel') setOutput(input.replace(/\s+(.)/g, (_, c) => c.toUpperCase()).replace(/^./, c => c.toLowerCase()))
  }

  return (
    <div>
      <textarea value={input} onChange={e => setInput(e.target.value)} rows={5} placeholder="Type or paste text here..." style={{ ...inputStyle, marginBottom: 10, resize: 'vertical' }} />
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 12 }}>
        {[['upper', 'UPPERCASE'], ['lower', 'lowercase'], ['title', 'Title Case'], ['sentence', 'Sentence case'], ['camel', 'camelCase']].map(([type, label]) => (
          <button key={type} onClick={() => convert(type)} style={btnSecondary}>{label}</button>
        ))}
      </div>
      {output && (
        <div style={resultBox}>
          <div style={{ color: '#F1F5F9', lineHeight: 1.6 }}>{output}</div>
          <button onClick={() => navigator.clipboard.writeText(output)} style={{ ...btnSecondary, marginTop: 8, fontSize: 12, padding: '4px 10px' }}>Copy</button>
        </div>
      )}
    </div>
  )
}

// BINARY CONVERTER
export function BinaryConverter({ tool: _ }: { tool: Tool }) {
  const [dec, setDec] = useState('42')
  const n = parseInt(dec) || 0

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Decimal number</label>
        <input type="number" value={dec} onChange={e => setDec(e.target.value)} style={inputStyle} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {[['Binary', n.toString(2), '#6366F1'], ['Hexadecimal', n.toString(16).toUpperCase(), '#8B5CF6'], ['Octal', n.toString(8), '#06B6D4'], ['Decimal', n.toString(), '#10B981']].map(([label, val, color]) => (
          <div key={label} style={{ background: '#111827', borderRadius: 8, padding: 12 }}>
            <div style={{ fontSize: 11, color: '#475569', marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 16, fontWeight: 600, fontFamily: 'monospace', color: color as string }}>{val}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// META TAG GENERATOR
export function MetaTagGenerator({ tool: _ }: { tool: Tool }) {
  const [title, setTitle] = useState('ToolVerse - Free Online Tools')
  const [desc, setDesc] = useState('50+ free online tools for calculators, PDF, image, SEO and developer utilities.')
  const [kw, setKw] = useState('free tools, online calculator, pdf tools')
  const [author, setAuthor] = useState('ToolVerse')

  const tags = `<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<meta name="description" content="${desc}">
<meta name="keywords" content="${kw}">
<meta name="author" content="${author}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${desc}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${title}">
<meta name="twitter:description" content="${desc}">`

  return (
    <div>
      {[['Page Title', title, setTitle], ['Description', desc, setDesc], ['Keywords', kw, setKw], ['Author', author, setAuthor]].map(([label, val, setter]) => (
        <div key={label as string} style={{ marginBottom: 12 }}>
          <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>{label as string}</label>
          <input type="text" value={val as string} onChange={e => (setter as (v: string) => void)(e.target.value)} style={inputStyle} />
        </div>
      ))}
      <pre style={{ ...resultBox, ...monoStyle, whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: '#10B981', marginTop: 14 }}>{tags}</pre>
      <button onClick={() => navigator.clipboard.writeText(tags)} style={{ ...btnSecondary, marginTop: 8 }}>Copy Tags</button>
    </div>
  )
}

// RANDOM NUMBER
export function RandomNumber({ tool: _ }: { tool: Tool }) {
  const [min, setMin] = useState('1')
  const [max, setMax] = useState('100')
  const [count, setCount] = useState('1')
  const [result, setResult] = useState<number[]>([])

  const gen = () => {
    const mn = parseInt(min), mx = parseInt(max), cnt = parseInt(count)
    setResult(Array.from({ length: cnt }, () => Math.floor(Math.random() * (mx - mn + 1)) + mn))
  }

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Minimum</label><input type="number" value={min} onChange={e => setMin(e.target.value)} style={inputStyle} /></div>
        <div><label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Maximum</label><input type="number" value={max} onChange={e => setMax(e.target.value)} style={inputStyle} /></div>
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Count</label>
        <input type="number" value={count} min={1} max={100} onChange={e => setCount(e.target.value)} style={{ ...inputStyle, maxWidth: 120 }} />
      </div>
      <button onClick={gen} style={btnPrimary}>🎲 Generate</button>
      {result.length > 0 && (
        <div style={{ ...resultBox, fontSize: parseInt(count) === 1 ? 40 : 18, fontWeight: 700, color: '#6366F1', textAlign: 'center', marginTop: 14 }}>
          {result.join(', ')}
        </div>
      )}
    </div>
  )
}

// DEFAULT (placeholder for tools not yet implemented)
export function DefaultTool({ tool }: { tool: Tool }) {
  return (
    <div style={{ padding: '40px 20px', textAlign: 'center' }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>{tool.icon}</div>
      <h3 style={{ fontSize: 18, fontWeight: 600, color: '#F1F5F9', marginBottom: 8 }}>{tool.name}</h3>
      <p style={{ color: '#94A3B8', fontSize: 14, marginBottom: 20 }}>{tool.longDescription}</p>
      <div style={{ background: '#111827', border: '1px dashed #1E2A3D', borderRadius: 8, padding: '20px', color: '#475569', fontSize: 13 }}>
        🚧 Full implementation available in the production build.<br />
        Connect your backend API to power this tool.
      </div>
    </div>
  )
}
