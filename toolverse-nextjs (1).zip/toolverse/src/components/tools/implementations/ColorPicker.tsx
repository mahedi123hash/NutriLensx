export { ColorPicker as default } from './index'
