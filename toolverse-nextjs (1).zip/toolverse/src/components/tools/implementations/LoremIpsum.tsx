export { LoremIpsum as default } from './index'
