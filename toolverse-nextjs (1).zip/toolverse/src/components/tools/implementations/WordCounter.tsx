export { WordCounter as default } from './index'
