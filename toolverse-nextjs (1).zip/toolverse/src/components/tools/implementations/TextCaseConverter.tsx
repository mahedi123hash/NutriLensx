export { TextCaseConverter as default } from './index'
