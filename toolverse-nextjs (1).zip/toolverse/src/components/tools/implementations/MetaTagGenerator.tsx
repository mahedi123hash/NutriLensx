export { MetaTagGenerator as default } from './index'
