export { DefaultTool as default } from './index'
