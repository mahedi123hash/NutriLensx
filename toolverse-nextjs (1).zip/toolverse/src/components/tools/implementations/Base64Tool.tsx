export { Base64Tool as default } from './index'
