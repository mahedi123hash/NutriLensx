export { BMICalculator as default } from './index'
