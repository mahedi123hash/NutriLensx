export { PercentageCalculator as default } from './index'
