export { PasswordGenerator as default } from './index'
