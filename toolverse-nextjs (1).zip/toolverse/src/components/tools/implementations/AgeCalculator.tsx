'use client'
import { useState } from 'react'
import { Tool } from '@/lib/tools'
import { inputStyle, btnPrimary, btnSecondary, resultBox } from './styles'

export default function AgeCalculator({ tool: _ }: { tool: Tool }) {
  const today = new Date().toISOString().split('T')[0]
  const [dob, setDob] = useState('1995-06-15')
  const [calcDate, setCalcDate] = useState(today)
  const [result, setResult] = useState<string | null>(null)

  const calculate = () => {
    const d = new Date(dob)
    const c = new Date(calcDate)
    let y = c.getFullYear() - d.getFullYear()
    let m = c.getMonth() - d.getMonth()
    let dd = c.getDate() - d.getDate()
    if (dd < 0) { m--; dd += new Date(c.getFullYear(), c.getMonth(), 0).getDate() }
    if (m < 0) { y--; m += 12 }
    const born = d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
    setResult(`${y} years, ${m} months, ${dd} days | Born: ${born}`)
  }

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Date of Birth</label>
        <input type="date" value={dob} onChange={e => setDob(e.target.value)} style={inputStyle} />
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 13, color: '#94A3B8', display: 'block', marginBottom: 5 }}>Calculate As Of</label>
        <input type="date" value={calcDate} onChange={e => setCalcDate(e.target.value)} style={inputStyle} />
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={calculate} style={btnPrimary}>Calculate Age</button>
        <button onClick={() => setResult(null)} style={btnSecondary}>Clear</button>
      </div>
      {result && (
        <div style={resultBox}>
          <div style={{ fontSize: 28, fontWeight: 700, color: '#6366F1' }}>{result.split('|')[0].trim()}</div>
          <div style={{ fontSize: 13, color: '#94A3B8', marginTop: 6 }}>{result.split('|')[1]?.trim()}</div>
        </div>
      )}
    </div>
  )
}
