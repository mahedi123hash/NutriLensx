export { UUIDGenerator as default } from './index'
