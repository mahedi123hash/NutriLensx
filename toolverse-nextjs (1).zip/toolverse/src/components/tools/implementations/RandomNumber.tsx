export { RandomNumber as default } from './index'
